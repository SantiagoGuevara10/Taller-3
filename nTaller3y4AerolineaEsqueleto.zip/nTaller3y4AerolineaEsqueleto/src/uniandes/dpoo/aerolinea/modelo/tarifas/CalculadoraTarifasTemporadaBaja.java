package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.Cliente;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas {
    @Override
    public double calcularTarifa(Vuelo vuelo, Cliente cliente) {
        // 
        return 0; // 
    }
}