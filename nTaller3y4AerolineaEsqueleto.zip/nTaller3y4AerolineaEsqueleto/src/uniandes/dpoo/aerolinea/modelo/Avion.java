package uniandes.dpoo.aerolinea.modelo;

public class Avion {
    private String modelo;
    private int capacidad;

    public Avion(String modelo, int capacidad) {
        this.modelo = modelo;
        this.capacidad = capacidad;
    }

    // Getters y setters
}